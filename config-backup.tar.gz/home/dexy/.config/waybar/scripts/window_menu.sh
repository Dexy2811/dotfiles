#!/bin/bash

hyprctl clients -j | jq -r '.[] | "\(.class) - \(.title) | \(.address)"' | \
  rofi -dmenu -p "Windows" | awk -F' | ' '{print $NF}' | \
  xargs -r -I{} hyprctl dispatch focuswindow address:{}
