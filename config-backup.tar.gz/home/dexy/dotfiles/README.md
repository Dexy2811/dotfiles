# dotfiles
my personal arch dotfiles
